"""
AI-Pulse REST API 和 RSS 模块
参考AIHOT的Agent接入功能，实现三大接口：REST API、RSS、SKILL.md
融合AIHOT的成熟设计：User-Agent策略、智能路由、人话输出规范等
"""
import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

import json
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta
from typing import Dict, List, Optional
from src.storage import HotStorage

storage = HotStorage()

# ========== 分类体系（对齐AIHOT的英文slug规范）==========

CATEGORY_MAP = {
    "ai-models": "模型发布/更新",
    "ai-products": "产品发布/更新",
    "industry": "行业动态",
    "paper": "论文研究",
    "tip": "技巧与观点",
    # 兼容旧格式
    "论文/研究": "paper",
    "模型发布": "ai-models",
    "行业动态": "industry",
    "技巧/观点": "tip"
}

# ========== REST API 数据接口 ==========

def get_items(mode: str = "selected", since: str = None, category: str = None, 
              q: str = None, take: int = 50, cursor: str = None,
              time_filter: str = None, date_start: str = None, date_end: str = None) -> Dict:
    """
    获取精选内容列表（对齐AIHOT的items API规范）
    Args:
        mode: selected(精选) / all(全部)
        since: ISO-8601时间（向后兼容）
        time_filter: today/yesterday/week/custom（前端直接传）
        date_start: 自定义开始日期 YYYY-MM-DD
        date_end: 自定义结束日期 YYYY-MM-DD
        category: 分类筛选
        q: 关键词搜索
        take: 返回数量
        cursor: 翻页游标
    Returns:
        JSON格式的数据列表
    """
    # 参数校验
    if mode not in ("selected", "all"):
        return {"error": "invalid mode (must be 'selected' or 'all')"}
    
    if take < 1 or take > 100:
        return {"error": "invalid take (must be integer 1-100)"}
    
    if category and category not in CATEGORY_MAP:
        valid = ", ".join(["ai-models", "ai-products", "industry", "paper", "tip"])
        return {"error": f"invalid category (must be one of: {valid})"}
    
    # 时间过滤逻辑（优先使用前端直接传的 time_filter）
    if time_filter:
        tf = time_filter
    elif since:
        try:
            since_date = datetime.fromisoformat(since.replace("Z", "+00:00"))
            days_ago = (datetime.now() - since_date).days
            if days_ago == 0: tf = "today"
            elif days_ago == 1: tf = "yesterday"
            elif days_ago <= 7: tf = "week"
            else: tf = "all"
        except:
            tf = "all"
    else:
        tf = "today"
    
    items = storage.query_selected(
        time_filter=tf, 
        category=category, 
        limit=take * 2, 
        include_unselected=(mode == "all"),
        custom_start=date_start,
        custom_end=date_end
    )  # 预留cursor空间
    
    # 模式过滤
    if mode == "selected":
        items = [i for i in items if i.get("selected", 1)]
    
    # 关键词搜索（优先使用FTS5全文检索，回退到ILIKE）
    if q:
        if len(q) < 2:
            q = None  # 单字符退化为全表扫，视作不搜索
        else:
            q_lower = q.lower()[:200]  # 最长200字
            
            # 尝试FTS5搜索
            try:
                fts_ids = storage.search_items_fts(q_lower, limit=take * 2)
                if fts_ids:
                    # FTS5命中，过滤结果
                    fts_id_set = set(fts_ids)
                    items = [i for i in items if i.get("id") in fts_id_set]
                else:
                    # FTS5未命中，回退到ILIKE
                    items = [i for i in items if q_lower in str(i.get("title", "")).lower() or 
                            q_lower in str(i.get("summary", "")).lower() or
                            q_lower in str(i.get("source", "")).lower()]
            except:
                # FTS5不可用，回退到ILIKE
                items = [i for i in items if q_lower in str(i.get("title", "")).lower() or 
                        q_lower in str(i.get("summary", "")).lower() or
                        q_lower in str(i.get("source", "")).lower()]
    
    # 应用cursor分页
    start_idx = 0
    if cursor:
        try:
            cursor_data = json.loads(cursor)
            start_idx = cursor_data.get("offset", 0)
        except:
            start_idx = 0
    
    end_idx = start_idx + take
    page_items = items[start_idx:end_idx]
    has_next = end_idx < len(items)
    
    # 生成nextCursor（不透明token）
    next_cursor = None
    if has_next:
        next_cursor = json.dumps({"offset": end_idx})
    
    # 转换为API格式（对齐AIHOT字段规范）
    result = []
    for item in page_items:
        title = item.get("title", "")
        title_en = item.get("title_en")
        
        # Parse tags
        tags_raw = item.get("tags", "[]")
        try:
            tags = json.loads(tags_raw) if isinstance(tags_raw, str) else (tags_raw or [])
        except:
            tags = []
        
        result.append({
                "id": str(item.get("id", "")),
                "title": title,
                "title_en": title_en if title_en and title_en != title else None,
                "url": item.get("url", ""),
                "source": item.get("source", ""),
                "source_tier": item.get("source_tier", "T2"),
                "publishedAt": item.get("publish_date", ""),
                "ingestedAt": item.get("ingested_at", ""),
                "crawlTime": item.get("crawl_time", ""),
                "summary": item.get("summary", ""),
                "full_content": item.get("full_content", ""),
                "content": item.get("content", ""),
                "category": item.get("category", ""),
                "content_type": item.get("content_type", ""),
                "final_score": item.get("final_score", 0),
                "recommendation_reason": item.get("recommendation_reason", ""),
                "tags": tags,
                "source_from": item.get("source_from", "original")
            })
    
    return {
        "count": len(result),
        "total": storage.count_selected(
            time_filter=tf,
            category=category,
            include_unselected=(mode == "all"),
            custom_start=date_start,
            custom_end=date_end
        ),
        "hasNext": has_next,
        "nextCursor": next_cursor,
        "items": result
    }

def get_daily(date: str = None) -> Dict:
    """
    获取AI日报（优先从数据库读取，如不存在则实时生成）
    Args:
        date: 日期，格式 YYYY-MM-DD，默认为最新
    Returns:
        日报内容，包含lead、sections、flashes
    """
    # 优先从数据库读取已存档的日报
    stored_report = storage.query_daily_report(date)
    
    if stored_report:
        return stored_report
    
    # 数据库中没有，尝试实时生成
    from src.daily_generator import generate_daily_report
    
    if date:
        result = generate_daily_report(date, storage)
    else:
        result = generate_daily_report(None, storage)  # 生成昨天日报
    
    return result

def get_dailies(take: int = 30) -> Dict:
    """
    获取日报列表（从数据库查询已存档的日报）
    对齐AIHOT的dailies API规范
    """
    if take < 1 or take > 180:
        take = 30
    
    # 从数据库查询已存档的日报
    dailies = storage.query_dailies(take=take)
    
    return {
        "count": len(dailies),
        "items": dailies
    }

# ========== RSS 订阅 ==========

def generate_rss(mode: str = "selected", limit: int = 20) -> str:
    """
    生成RSS订阅XML（对齐AIHOT的RSS规范）
    """
    items = storage.query_selected(time_filter="week", limit=limit)
    if mode == "selected":
        items = [i for i in items if i.get("selected", 1)]
    
    # 创建RSS根元素
    rss = ET.Element("rss", version="2.0")
    channel = ET.SubElement(rss, "channel")
    
    # 频道信息
    ET.SubElement(channel, "title").text = "AI-Pulse 精选时间线"
    ET.SubElement(channel, "description").text = "全行业高信噪比情报流水线，AIHOT风格的AI资讯精选"
    ET.SubElement(channel, "link").text = "http://localhost:7861"
    ET.SubElement(channel, "language").text = "zh-CN"
    ET.SubElement(channel, "lastBuildDate").text = datetime.now().strftime("%a, %d %b %Y %H:%M:%S +0800")
    
    # 添加条目
    for item in items:
        entry = ET.SubElement(channel, "item")
        ET.SubElement(entry, "title").text = item.get("title", "")
        ET.SubElement(entry, "link").text = item.get("url", "")
        ET.SubElement(entry, "description").text = item.get("summary", "")
        ET.SubElement(entry, "pubDate").text = datetime.now().strftime("%a, %d %b %Y %H:%M:%S +0800")
        ET.SubElement(entry, "category").text = item.get("source_tier", "T2")
        
        # 添加评分作为自定义元素
        score = item.get("final_score", 0)
        score_elem = ET.SubElement(entry, "score")
        score_elem.text = str(score)
    
    return '<?xml version="1.0" encoding="UTF-8"?>\n' + ET.tostring(rss, encoding="unicode")

# ========== SKILL.md 标准（融合AIHOT的成熟设计）==========

def generate_skill_md() -> str:
    """生成SKILL.md标准文件，供任意Agent使用（融合AIHOT的设计精华）"""
    return '''# AI-Pulse Skill

让 Agent 用最自然的中文查询拿到 aipulse 上每天的 AI HOT 日报和全部 AI 动态，不需要打开浏览器。SKILL.md 标准格式，跨 Claude Code / Codex CLI / Cursor / Gemini CLI / OpenCode / 任何兼容平台可用。

线上：http://localhost:7861（本地匿名可访，无需 token）

## 先决条件：必须带 User-Agent（仅 API 端点）

`/api/public/*` 走 UA 黑名单挡商业爬虫，默认 `curl/X.Y` UA 可能会被 403 Forbidden。**调 API 时所有 curl 都必须带浏览器 UA + aipulse-skill 标识**：

```bash
UA="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 aipulse-skill/0.1.0"

# 之后所有调 API 的 curl 都加 -H "User-Agent: $UA"，例如：
curl -sH "User-Agent: $UA" "http://localhost:7861/api/public/daily"
```

> `aipulse-skill/0.1.0` 后缀让后台能区分"通过 skill 调用"和"普通 API 直接调用"的流量。删掉不影响功能；保留有助于产品改进。

后面"工作流"章节的 curl 例子为了简洁默认你已经设了 `$UA`——实际调用必须加 `-H "User-Agent: $UA"`，**不要忘**。漏掉这一步会让你以为接口挂了，实际只是被 403 挡了。

> **范围澄清**：这条 UA 要求**只针对 `/api/public/*` API 端点**。`/aipulse-skill/{SKILL.md}` 安装入口**特意豁免** UA 黑名单（设计前提就是给 `curl -fsSL ... | bash` 一行装用），用 default curl UA 直通 200。

## 什么时候用

> **路由优先级（第一原则）**：**默认走精选** `items?mode=selected`——它是 AI-Pulse 每天精挑细选的"主菜单"，覆盖用户关心的事且数据新鲜。
>
> - **仅当用户在话里明确说出"日报"** 二字才走 `daily`（编辑成品，按 UTC 整日切片，跟"过去 24 小时 / 今天"等滚动窗口对不上）
> - **仅当用户明确说"全部 / 完整 / 所有 / 全量"** 才走 `mode=all`（含未精选的次要条目，量大但杂）
> - **"今天 AI 圈"、"过去 24 小时大新闻"、"最近 AI 圈有啥"** 等宽问题 = **默认精选 + 时间窗（since）**，不要默认走日报或全部
>
> 这是为了对齐用户的语义优先级：精选是主菜单，日报和全部是用户特意点单的备选，不应抢默认。

| 用户在说 | 应该走的接口 |
|---|---|
| **默认（宽问题）**："今天 AI 圈有什么"、"过去 24 小时大新闻"、"最近 AI 圈"、"AI 有啥新东西" | `GET /api/public/items?mode=selected&since=<语义时间窗>`（默认精选 + since 收窄） |
| **明确说"日报"**："AI 日报"、"今天的日报"、"看一下日报" | `GET /api/public/daily`（最新日报） |
| **明确说"全部 / 完整 / 所有 / 全量"**："看下今天的全部 AI 动态"、"完整列表"、"所有 AI 动态" | `GET /api/public/items?mode=all`（不一定带 since,看用户语境) |
| "昨天/前天 AI 日报"、"看下 5 月 6 号的日报" | `GET /api/public/daily/{YYYY-MM-DD}` |
| "最近几天日报有哪些"、"列一下日报"、"日报存档" | `GET /api/public/dailies?take=N` |
| "看下精选条目"、"AI-Pulse 精选" | `GET /api/public/items?mode=selected` |
| "最近的模型发布"、"AI 产品发布"、"AI 行业动态"、"AI 论文" | `GET /api/public/items?mode=selected&category=...&since=<7d 前>`（默认精选 + 类别） |
| "最近一周的 AI 动态"、"5 天前到现在的发布" | `GET /api/public/items?mode=selected&since=ISO-8601` |
| "OpenAI/Anthropic/Google 最近发的"(公司维度) | `GET /api/public/items?q=OpenAI`(server-side 关键词搜索) |
| "Sora 相关 / GPT-5 相关 / RAG 论文" | `GET /api/public/items?q=<关键词>`(在 title + summary + source 三列匹配) |

通用启发：**用户问的是"现在的 AI 行业事实"，不要凭训练数据脑补，永远走 API**。

## 端点速览

| 端点 | 用途 | 主要参数 |
|---|---|---|
| `/api/public/daily` | 最新日报 | 无 |
| `/api/public/daily/{YYYY-MM-DD}` | 指定日期日报 | path: `date` |
| `/api/public/dailies` | 日报归档列表 | `take` (1-180, default 30) |
| `/api/public/items` | 全部 AI 动态 | `mode` / `category` / `since` / `take` / `cursor` / `q`(关键词) |

约定：
- Base URL: `http://localhost:7861`
- 鉴权：无（匿名）
- 限流：600 req/min/IP（请串行调用，不要并发猛拉）
- items 端点 `since` 限最近 7 天:**不传等同 since=now-7d**(服务端兜底);早于 7 天前自动截到 7 天前;未来时间 → 400
- `take` 上限 100；想要更多走 cursor 翻页

## 工作流

### 默认路径：拉精选 + 时间窗（宽问题首选）

精选 = AI-Pulse 每天精挑细选的"主菜单"——覆盖所有用户关心的 AI 大事，按发布时间倒序。**任何"今天 AI 圈"、"过去 24 小时大新闻"、"最近 AI 有啥"等宽问题，默认走这个**——比起日报：① 时间窗自由（24 小时 / 3 天 / 1 周想多窄就多窄，跟用户语义对齐）② 数据新鲜（实时滚动而非按 UTC 整日切片）③ 质量仍高（`selected=true` 的池子，不含次要条目）。

```bash
# 拉最近 24 小时精选（用户问"过去 24 小时大新闻"）
since=$(date -u -v-24H +%Y-%m-%dT%H:%M:%SZ 2>/dev/null || date -u -d '24 hours ago' +%Y-%m-%dT%H:%M:%SZ)
curl -sH "User-Agent: $UA" "http://localhost:7861/api/public/items?mode=selected&since=$since&take=50"

# 拉最近 50 条精选（用户问"看下精选" / 不带明确时间窗）
curl -sH "User-Agent: $UA" "http://localhost:7861/api/public/items?mode=selected&take=50" \\
  | jq '.items[] | {title, source, publishedAt, url}'
```

### 拉日报（用户明确说"日报"时）

**触发关键词**：句子里出现"日报"二字（"AI 日报"、"今天的日报"、"看下日报"、"5 月 6 号的日报"）。**没有"日报"二字不要走这个**——日报是 UTC 0 点切片的固定一日成品，跟"过去 24 小时 / 今天"等滚动时间窗对不上。

日报是 AI-Pulse 的"标题层"——每天北京时间 08:00 自动生成，按主题分版块（5 个固定版块）。

```bash
# 拉今日（或最新可用的）日报
curl -sH "User-Agent: $UA" "http://localhost:7861/api/public/daily" \\
  | jq '{date, lead: .lead.title, sections: [.sections[] | {label, n: (.items | length)}]}'
```

### 拉指定日期日报

```bash
# YYYY-MM-DD，UTC 0 点为基准
curl -sH "User-Agent: $UA" "http://localhost:7861/api/public/daily/2026-05-19"
```

### 列日报归档（discovery）

不知道有哪些日期可查时，先看归档：

```bash
# 最近 N 天日报索引（不含正文，只有日期 + 头条标题）
curl -sH "User-Agent: $UA" "http://localhost:7861/api/public/dailies?take=14" \\
  | jq '.items[] | {date, leadTitle}'
```

### 拉全部（用户明确说"全部 / 完整 / 所有 / 全量"时）

**触发关键词**：句子里出现"全部"、"完整"、"所有"、"全量"、"包括老的"——用户主动想看精选之外的次要条目。**没有这些关键词不要走 mode=all**——精选已经覆盖大部分用户关心的事，全部池子量大但杂。

```bash
# 拉最近 24 小时全部 AI 动态（用户问"看下今天全部的 AI 动态"）
since=$(date -u -v-24H +%Y-%m-%dT%H:%M:%SZ 2>/dev/null || date -u -d '24 hours ago' +%Y-%m-%dT%H:%M:%SZ)
curl -sH "User-Agent: $UA" "http://localhost:7861/api/public/items?mode=all&since=$since&take=100"
```

### 按分类拉条目

5 个 category(items API 用英文 slug,daily API 看到的 section label 是中文):

| `items?category=` | `daily.sections[].label` |
|---|---|
| `ai-models` | 模型发布/更新 |
| `ai-products` | 产品发布/更新 |
| `industry` | 行业动态 |
| `paper` | 论文研究 |
| `tip` | 技巧与观点 |

```bash
# 例：拉最近 50 条 AI 论文（默认精选 + paper 类别）
curl -sH "User-Agent: $UA" "http://localhost:7861/api/public/items?mode=selected&category=paper&take=50" \\
  | jq '.items[] | {title, source, publishedAt, url}'

# 例：精选里的模型发布
curl -sH "User-Agent: $UA" "http://localhost:7861/api/public/items?mode=selected&category=ai-models&take=20"
```

### 按时间窗口拉条目（最近 N 天）

> **关键规则**:用户问"**最近** X"(最近的模型发布 / 最近 AI 论文 / 最近 OpenAI 等)时,需要带 `since` 参数把窗口收窄到用户实际意图。
>
> **服务端兜底**:items API 服务端默认 `since=now-7d`(硬上限,保护服务器),所以即使 Skill 完全不带 since 也只会返回最近 7 天的内容。但**仍建议显式带 since**:① 用户问"最近 3 天" 时显式 3d 比让服务端默认 7d 更精确 ② 输出元信息可以写人话级时间窗 ③ 跟用户公开宣传的"最长 7 天"对齐意图清晰。

```bash
# 拉最近 7 天的精选模型发布(用户问"最近的模型发布")
since=$(date -u -v-7d +%Y-%m-%dT%H:%M:%SZ 2>/dev/null || date -u -d '7 days ago' +%Y-%m-%dT%H:%M:%SZ)
curl -sH "User-Agent: $UA" "http://localhost:7861/api/public/items?mode=selected&category=ai-models&since=$since&take=100"

# 拉最近 3 天的精选动态(用户明确说"最近 3 天")
since=$(date -u -v-3d +%Y-%m-%dT%H:%M:%SZ 2>/dev/null || date -u -d '3 days ago' +%Y-%m-%dT%H:%M:%SZ)
curl -sH "User-Agent: $UA" "http://localhost:7861/api/public/items?mode=selected&since=$since&take=100"
```

### 翻页（cursor）

`/api/public/items` 响应里有 `nextCursor`（opaque token），下次请求把它原样塞进 `cursor` 参数即可。

```bash
# 第 1 页
resp1=$(curl -sH "User-Agent: $UA" "http://localhost:7861/api/public/items?mode=all&take=100")
echo "$resp1" | jq '.items | length'   # 100

# 第 2 页
cursor=$(echo "$resp1" | jq -r '.nextCursor')
curl -sH "User-Agent: $UA" "http://localhost:7861/api/public/items?mode=all&take=100&cursor=$cursor"
```

`hasNext = false` 或 `nextCursor = null` 时停止翻页。**cursor 是不透明 token,视作黑盒,不要尝试解析、递增、或跨端点复用**。

### 关键词搜索（"OpenAI 最近发的" / "Sora 相关" / "RAG 论文"）

API 直接支持 server-side 关键词搜索 — `q` 参数在 `title` + `summary` + `source` 三列上 ILIKE 匹配。**不要再走"拉一批 + 客户端 jq grep"模式**。

```bash
# 找 OpenAI 最近发的(覆盖全池)
curl -sH "User-Agent: $UA" "http://localhost:7861/api/public/items?q=OpenAI&take=30"

# 找 Sora 相关的所有 AI 动态
curl -sH "User-Agent: $UA" "http://localhost:7861/api/public/items?q=Sora"

# 关键词 + 时间窗(Anthropic 最近 3 天的精选)
SINCE=$(date -u -v-3d +%Y-%m-%dT%H:%M:%SZ 2>/dev/null || date -u -d '3 days ago' +%Y-%m-%dT%H:%M:%SZ)
curl -sH "User-Agent: $UA" "http://localhost:7861/api/public/items?mode=selected&q=Anthropic&since=$SINCE"
```

`q` 约束:
- 至少 2 个字符(单字符退化为全表扫,服务端会视作不搜索)
- 最长 200 字(超出自动截断)
- 跟其它参数(mode/category/since/take/cursor)正交叠加

## 返回数据形态

### `/api/public/daily` 返回

```json
{
  "date": "2026-05-19",
  "generatedAt": "2026-05-19T00:01:23.456Z",
  "windowStart": "2026-05-18T00:00:00.000Z",
  "windowEnd":   "2026-05-19T00:00:00.000Z",
  "lead": { "title": "...", "leadParagraph": "..." },
  "sections": [
    {
      "label": "模型发布/更新",
      "items": [
        {
          "title": "...",
          "summary": "...",
          "sourceUrl": "https://...",
          "sourceName": "OpenAI Blog"
        }
      ]
    }
  ],
  "flashes": [
    { "title": "...", "sourceName": "...", "sourceUrl": "...", "publishedAt": "..." }
  ],
  "content": "# AI Pulse 日报...",
  "total_items": 25
}
```

`sections[].label` 固定 5 个："模型发布/更新" / "产品发布/更新" / "行业动态" / "论文研究" / "技巧与观点"。

### `/api/public/dailies` 返回

```json
{
  "count": 14,
  "items": [
    { "date": "2026-05-19", "generatedAt": "...", "leadTitle": "..." }
  ]
}
```

### `/api/public/items` 返回

```json
{
  "count": 50,
  "hasNext": true,
  "nextCursor": "eyJvZmZzZXQiOiA1MH0",
  "items": [
    {
      "id": "1",
      "title": "中文标题（normalize 过）",
      "title_en": "原英文标题（仅当与 title 不同时存在，否则 null）",
      "url": "https://...",
      "source": "信源名称",
      "publishedAt": "2026-05-19T15:30:00.000Z",
      "ingestedAt": "2026-05-19T16:00:00.000Z",
      "summary": "中文摘要（LLM 生成）",
      "category": "ai-models"
    }
  ]
}
```

字段不变量：

- 必有：`id` / `title` / `url` / `source`
- 可空：`title_en` / `summary` / `publishedAt` / `ingestedAt` / `category`
- `category` 取值集：`ai-models` / `ai-products` / `industry` / `paper` / `tip` / `null`
- `publishedAt`：原文发布时间，ISO 8601 UTC（带 `Z`）
- `ingestedAt`：录入系统时间，ISO 8601 UTC（带 `Z`）
- `id`：字符串，**不要假设是数字**

## 给用户的输出格式

> ⚠️ **核心原则**：这一节是**直接展示给用户的最终内容**——必须 markdown 格式 + 排版好 + **普通人能看得懂的人话**。用户多数是非技术 AI 创业者 / 设计师 / 普通读者，看到的应该是中文资讯简报，**不是 API 调试日志**。
>
> 所有"端点路径 / `mode=selected` 这种 raw 参数 / 限流 / nginx 缓存 / cursor / hasNext"等基础设施细节**都不能出现**在用户看到的输出里。**人话**级元数据（时间窗 / 条数 / "按发布时间倒序"）可以保留——判断标准：用户能直接看懂吗？能 → 保留；不能 → 删掉。

### 日报式输出（用 daily / daily/{date} 端点时）

```markdown
**AI-Pulse 日报 · 2026-05-19**

## 模型发布/更新
1. **<title>** — <source>
   <summary 简化版 50 字内>
   <url>

## 产品发布/更新
2. ...

## 行业动态
3. ...

## 论文研究
4. ...

## 技巧与观点
5. ...

## 快讯（如果 flashes 有内容）
- <flash.title> — <flash.source>（<flash.publishedAt 转人话>）
```

**编号贯穿全文**（1, 2, 3 ... N），不在每个 ## 内重新计数——这样用户能一眼数到"今天 27 条"。

### 列表式输出（用 items 端点时）

**默认按 category 分组 + 全局编号**——用户对"模型/产品/行业/论文/技巧"五版块结构已经形成预期：

```markdown
**AI-Pulse — 最近 30 条精选**

## 模型发布/更新
1. **<title>** — <source>
   2 小时前
   <summary>
   <url>

## 产品发布/更新
2. **<title>** — <source>
   ...

3. ...

## 行业动态
4. ...
```

**只有 1 个 category** 时（用户明确说"AI 论文"/"模型发布"等），用扁平编号列表：

```markdown
**AI-Pulse — 最近一周 AI 论文**（2026-05-01 ~ 2026-05-19）

1. **<title>** — <source>
   <summary>
   <url>

2. ...
```

### 副标题／元信息只写人话

**OK**（用户能直接懂的）：

- "时间窗 2026-05-05 ~ 2026-05-19"
- "最近 3 天命中 OpenAI 关键词的全部条目"
- "按发布时间倒序"
- "共 50 条"
- "今天 5/19 日报北京时间 08:00 后才生成，先看 5/18 这期"

**不 OK**（基础设施泄漏，坚决不写）：

- ❌ `mode=selected` / `category=paper` / `take=30` 这种 raw 参数名
- ❌ 端点路径 `/api/public/items?since=2026-04-30T18:39:31Z&take=50`
- ❌ "限流 600 req/min" / "nginx 缓存 60s" / "x-nginx-cache: HIT"
- ❌ "cursor" / "hasNext=true" / "需 cursor 翻页或缩小 since 窗口"
- ❌ 任何 HTTP 状态码 / cache 状态 / 后端机制描述

数据源最多写一句：**"数据来自 AI-Pulse 情报流水线"**，要么干脆不提。

### 时间转人话

`publishedAt` 是 ISO 8601 UTC，展示时**必须**转成北京时间 + 用户能扫读的相对/绝对时间：

| 内部值 | 展示给用户 |
|---|---|
| `2026-05-19T01:48:00.000Z` | "今天上午 09:48" / "2 小时前" |
| `2026-05-18T18:08:17.000Z` | "今天凌晨 02:08" / "10 小时前" |
| `2026-05-17T16:43:00.000Z` | "5/18 00:43" / "昨天" |

**不要**直接展示 `2026-05-19T15:30:00.000Z` 这种 ISO 字符串——用户看不懂。

### title vs title_en

默认输出 `title`（中文 normalize 过的）。`title_en` 只在以下场景才用：

- 用户明确要求英文版（"用英文给我看一下"）
- `title` 为空（极少见）

**不要**两个都展示。

## 常见错误处理

- `{"error":"No daily report available yet."}`（HTTP 404）：当天日报还没生成（北京时间 08:00 之前）。建议给用户：拉昨天日报
- `{"error":"Invalid date format..."}`（HTTP 400）：date 必须是 `YYYY-MM-DD`，UTC 基准
- items 端点常见 400：
  - `"invalid mode (must be \'selected\' or \'all\')"`
  - `"invalid category (must be one of: ai-models, ai-products, industry, paper, tip)"`
  - `"invalid since (must be ISO date, not in future)"`
  - `"invalid take (must be integer 1-100)"`
- HTTP 429（限流）：单 IP 超 600 req/min。串行调用 + 翻页加 200ms 间隔即可

## 不要做

- **不要把"今天 AI 圈"、"过去 24 小时大新闻"、"最近 AI 圈有啥"等宽问题路由到 daily** — 这些是滚动时间窗，daily 是 UTC 0 点切片（5/6-5/7 一整天）的固定一日成品，时间精度对不上。**默认走 `mode=selected + since=<语义窗>`**。仅当用户在话里明确说"日报"二字才走 `daily`
- **不要在用户没说"全部 / 完整 / 所有 / 全量"时默认走 `mode=all`** — 精选已经覆盖大部分用户关心的事，全部池子量大但杂含未精选次要条目。默认 `mode=selected`，只有用户主动点单"全部"才切到 `mode=all`
- 不要试图猜测 / 编造内容 — 永远以 API 返回为准
- 不要把摘要（`summary`）当原文引用 — 摘要由 LLM 生成，引用需要回 `url` / `sourceUrl` 核对
- 不要做高频轮询 — 日报每天 08:00 才更新一次，items 端点 5 分钟服务端缓存，用户问相同问题时不需要重新调 API
- 不要并发猛拉翻页 — 串行 + 自然间隔
- 不要尝试解析 / 递增 / 跨端点复用 cursor — 它是不透明 token,内部编码格式不稳定,改了不通知
- 公司维度 / 关键词查询用 server-side `?q=<词>`,不要走"拉一批 + 客户端 jq grep"(那只能看到前 100 条池子,会漏)
- **用户问"最近 N 天 X" 时显式带 `since=<N天前>`**(意图明确 + 元信息能写人话时间窗)
- **不要在用户输出里暴露端点路径 / raw 参数 / 限流 / 缓存 TTL / cursor / hasNext 等基础设施细节** — 这些是给开发者看的，用户看不懂
- **不要在压缩 / 跨日 / 跨版块合并输出时丢掉每条的 sourceUrl** — 即使你为篇幅把 3 个日报合并成 5 类总结，每条 item 也必须保留 url（标题后或单独一行）
- **不要把"端点路径 / 调用细节"作为输出的引用源** — 引用源就写 `<source>`（OpenAI 官网 / Anthropic Newsroom / X：Berry Xia 这种）

## RSS 订阅

也可以通过 RSS 阅读器订阅：

```
http://localhost:7861/api/public/rss
```

支持模式参数：

- `http://localhost:7861/api/public/rss?mode=selected` - 仅精选内容（默认）
- `http://localhost:7861/api/public/rss?mode=all` - 全部内容
'''

if __name__ == "__main__":
    # 测试API
    print("=== 测试 API ===")
    result = get_items(mode="selected", take=5)
    print(f"获取到 {result.get('count', 0)} 条内容")
    if "error" in result:
        print(f"错误: {result['error']}")
    
    print("\n=== 测试分类过滤 ===")
    result_paper = get_items(mode="selected", category="paper", take=5)
    print(f"论文分类: {result_paper.get('count', 0)} 条")
    
    print("\n=== 测试日报 ===")
    daily = get_daily()
    if "error" in daily:
        print(f"日报: {daily['error']}")
    else:
        print(f"日报: {daily['date']}, {daily['total_items']} 条")
        print(f"版块: {[s['label'] for s in daily.get('sections', [])]}")
    
    print("\n=== 测试 RSS ===")
    rss = generate_rss()
    print(f"RSS 长度: {len(rss)} 字符")
    print(rss[:200] + "...")
    
    print("\n=== 测试 SKILL.md ===")
    skill = generate_skill_md()
    print(f"SKILL.md 长度: {len(skill)} 字符")
    print("核心特性: User-Agent策略 / 智能路由 / 人话输出规范 / Cursor分页 / 分类体系")